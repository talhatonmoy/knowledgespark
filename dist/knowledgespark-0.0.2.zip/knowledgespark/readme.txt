=== KnowledgeSpark ===
Contributors: knowledgespark
Tags: internal links, editorial, qdrant, ai
Requires at least: 6.4
Requires PHP: 7.4
Stable tag: 0.0.2
License: GPLv2 or later

Reader-focused internal link suggestions in the WordPress post editor. The same suggest and apply-all actions are also registered as WordPress abilities, so AI agents can interlink posts through WordPress MCP plugins such as MCP Adapter.

== Description ==
KnowledgeSpark searches a dedicated Qdrant Cloud collection and optionally uses an OpenAI-compatible chat API to review candidates for reader usefulness. Suggestions include a target, reason, and verified existing anchor/quote when available. Apply All Links (after your confirmation) wraps each suggested anchor phrase in its target link, saves the post, and reloads the editor. Otherwise, place links manually.

Version 0.0.1 supports public published posts as link targets, Gutenberg and the Classic Editor, an adjustable result count (default five, maximum ten), Apply All Links with confirmation, automatic save, and editor reload, connection testing, incremental indexing, and scheduled updates through WordPress cron. Current unsaved draft text is used for suggestions.

== Installation ==
1. Activate KnowledgeSpark in WordPress Plugins.
2. Open Settings > KnowledgeSpark.
3. Enter your Qdrant Cloud HTTPS cluster URL and API key. Use a dedicated collection for this site; do not reuse an unrelated collection.
4. Enable Cloud Inference in the cluster console. Verify the selected model is available and labelled free. The default sentence-transformers/all-MiniLM-L6-v2 model requires 384 dimensions.
5. Optionally configure an OpenAI-compatible API base URL, API key, and model supporting chat completions with JSON object responses. AI costs are separate from Qdrant's free tier. Without AI, semantic matches remain available.
6. Save settings, test the connection, and index published posts. Keep this page open until indexing finishes. Errors are shown; rerun indexing to retry.
7. Edit a post, set the maximum recommendation count, and click KnowledgeSpark. Review the proposed destination, reason, and placement, then click Apply All Links to insert, save, and reload, or add links yourself with the normal editor link tool.

The server needs outbound HTTPS access to the configured services. API credentials are stored in the WordPress options database and are never sent to the browser. Protect database backups accordingly. Only administrators can configure or index; suggestions require permission to edit the source post.

== Agent tools via WordPress MCP ==

KnowledgeSpark registers four WordPress abilities on the core Abilities API (part of WordPress core since 6.9), so AI agents such as OpenCode or DeepSeek can interlink posts end-to-end without opening the editor:

- find suggestions (`knowledgespark/find-suggestions`) — the KnowledgeSpark button: suggestions for a saved post with target title, URL, reason, and a verified anchor phrase.
- apply all links (`knowledgespark/apply-all-links`) — the Apply All Links button: inserts the given links into a saved post, with every placement guard and per-cause skip report of the editor flow.
- interlink (`knowledgespark/interlink`) — both buttons in one call: find suggestions, keep the applicable ones (non-empty anchor and valid URL, the editor button's filter), apply them, and report inserted and skipped links with their causes.
- list published posts (`knowledgespark/list-posts`) — published posts with ID, title, URL, and modified time, cursor-paged, so an agent can pick targets.

Setup:

1. Install a WordPress MCP plugin on the site. MCP Adapter (the official one, from the plugin directory) exposes the abilities over MCP; point any MCP client that supports the Streamable HTTP transport at `/wp-json/mcp/mcp-adapter-default-server`. With the default server, agents discover abilities through its meta-tools (`mcp-adapter-discover-abilities`, `mcp-adapter-get-ability-info`, `mcp-adapter-execute-ability`) and execute them by name.
2. Authenticate as a WordPress user with permission to edit the target posts, using an Application Password created under Users → Profile. Use a dedicated user with the minimum role, and revoke the password when agent access is no longer needed.
3. On HTTPS sites Application Passwords work out of the box. On plain-HTTP sites (local development such as DevKinsta), enable Settings → KnowledgeSpark → "Allow Application Password access" first; it exists only for local or development sites because credentials travel unencrypted over HTTP.
4. Example call:

curl -s -X POST "https://example.com/wp-json/mcp/mcp-adapter-default-server" --user "user:application-password" -H "Content-Type: application/json" -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"mcp-adapter-execute-ability","arguments":{"ability_name":"knowledgespark/interlink","parameters":{"post_id":123}}}}'

OpenCode connects to the same URL as a remote MCP server (type "remote" in its MCP configuration); DeepSeek Harness connects through its MCP connection settings using the HTTP transport and the same Basic-auth credentials. Sites running the abilities plugin behind the Novamira CLI should surface the same abilities through `novamira discover`/`run`; verify on your production site after deploying.

Suggestion calls run the same engine as the editor, including the optional AI review, so allow roughly 30–90 seconds per find-suggestions or interlink call and raise the client's tool timeout accordingly. Every agent apply passes through the same placement guards as the editor: unplaceable anchors are skipped with their cause, never forced.

== External services ==
Qdrant Cloud: sends compact published post title, headings, excerpt text, post ID, URL, and modification date during indexing. Queries contain current draft title, opening text, and up to five headings. Requires an account, cluster, and API key.
Documentation: https://qdrant.tech/documentation/inference/cloud-inference/
Privacy: https://qdrant.tech/legal/privacy-policy/

Optional AI API: sends current article text (up to 8,000 characters), title, and up to 12 candidate titles and leading excerpts (up to 1,500 characters each) when the editor explicitly requests suggestions. The configured provider's pricing, terms, and privacy policy apply. Default endpoint: https://api.openai.com/v1
Default provider terms: https://openai.com/policies/terms-of-use/
Default provider privacy: https://openai.com/policies/privacy-policy/

== Limitations ==
This is an early MVP. Retrieval uses one compact vector per post and heading queries, not full section indexing. Model input windows may truncate the compact representation. AI evaluates supplied excerpts, not every candidate's complete article. Always review the target before linking. No numerical confidence scores, feedback learning, or persistent recommendation cache are included. Apply All Links only wraps the exact verified anchor phrase in the target link; anchors that would overlap a block, a link, or partial formatting are skipped and reported, never forced.

Only the post post-type is supported. Noindex metadata from third-party SEO plugins is not inspected. Existing links are detected via WordPress URL resolution; custom redirect aliases may not resolve. Deleted, unpublished, and password-protected targets are also checked against WordPress at recommendation time, even if the cloud index is stale.

WP-Cron depends on site traffic. Use a real cron runner for reliable synchronization. Indexing checks the configured collection and skips unchanged, already embedded posts. Missing or changed posts are embedded; normal saves synchronize only the saved post. Progress shows indexed, skipped, and failed counts. Keep the settings page open while indexing; supported browsers warn before leaving during a run. Restarting safely checks completed work without embedding it again. The settings page shows batch failures. Individual cron failures are stored under the post's _ks_sync_error metadata. Deleting the plugin does not delete your cloud collection or settings. Reset collection deletes the configured collection and must be confirmed. Qdrant requests retry automatically twice (with backoff) on transient TLS or network errors; AI responses that come back unparseable (typically token truncation from the model's internal reasoning) are retried once, and failures report finish reason and token counts for diagnosis.

Changing embedding models requires a new collection and full indexing, even if dimensions match. Free-tier quotas and free model availability must be verified in Qdrant's console. Test connection validates cluster/collection access; indexing verifies inference access. No live external account was configured during development.

== Changelog ==
= 0.0.2 =
* Agent tools: find suggestions, apply all links, interlink, and list posts are registered as WordPress abilities and exposed to AI agents through WordPress MCP plugins such as MCP Adapter (Application Password authentication; explicit opt-in setting for plain-HTTP development sites). No change to the editor flow, the suggestion engine, or the placement guards.

= 0.0.1 =
Initial MVP: settings, Qdrant Cloud Inference indexing, editorial suggestions, optional AI review, and manual link placement.
